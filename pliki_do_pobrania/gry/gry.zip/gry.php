<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gry komputerowe</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>
    <header>
        <h1>Ranking gier komputerowych</h1>
    </header>
    <aside id="lewy">
        <h3>Top 5 gier w tym miesiącu</h3>
        <ul>
            <?php
                $pol = mysqli_connect('localhost','root','','gry');
                $zap1 = mysqli_query($pol,"SELECT nazwa,punkty FROM gry ORDER BY punkty DESC LIMIT 5");
                while ($dane = mysqli_fetch_row($zap1)) {
                    echo "
                        <li>
                            $dane[0] <label class='indicator'>$dane[1]</label>
                        </li>
                    ";
                }
            ?>
        </ul>
        <h3>Nasz sklep</h3>
        <a href="http://sklep.gry.pl">Tu kupisz gry</a>
        <h3>Stronę wykonał</h3>
        <p>WL & SS</p>
    </aside>
    <main>
        <?php
            $zap2 = mysqli_query($pol,"SELECT id,nazwa,zdjecie FROM gry");
            while ($dane = mysqli_fetch_row($zap2)) {
                echo "
                    <section class='blok_gry'>
                        <img src='$dane[2]' alt='$dane[1]' title='$dane[0]'>
                        <p>$dane[1]</p>
                    </section>
                ";
            }
        ?>
    </main>
    <aside id="prawy">
        <h3>Dodaj nową grę</h3>
        <form action="" method="POST">
            <label>nazwa<br><input type="text" name="input_nazwa"></label><br>
            <label>opis<br><input type="text" name="input_opis"></label><br>
            <label>cena<br><input type="text" name="input_cena"></label><br>
            <label>zdjęcie<br><input type="text" name="input_zdjecie"></label><br>
            <input type="submit" value="DODAJ">
        </form>
        <?php

            @$nazwa = $_POST['input_nazwa'];
            @$opis = $_POST['input_opis'];
            @$cena = $_POST['input_cena'];
            @$zdjecie = $_POST['input_zdjecie'];

            if ($nazwa != "") {
                $zap4 = mysqli_query($pol, "INSERT INTO gry VALUES (NULL,'$nazwa','$opis',0,'$cena','$zdjecie')");
            }
            else {

            }
        ?>
    </aside>
    <footer>
        <form action="" method="POST">
            <input type="text" name="input_pokaz_opis">
            <input type="submit" value="Pokaż opis">
        </form>
        <?php
            @$opis = $_POST['input_pokaz_opis'];

            if ($opis != "") {
            $zap2 = mysqli_query($pol,"SELECT nazwa,LEFT(opis, 100),punkty,cena FROM gry WHERE id=$opis");
                $dane = mysqli_fetch_row($zap2) ;
                echo "
                    <h2>
                        $dane[0], $dane[2] punktów, $dane[3] zł
                    </h2>
                    <p>
                        $dane[1];
                    </p>
                ";}
                else {
                    echo "";
                }
            
        ?>
    </footer>
</body>
</html>
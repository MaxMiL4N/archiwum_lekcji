<?php
    echo "Nowy plik<br>"
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Opinie klientów</title>
    <link rel="stylesheet" href="styl3.css">
</head>
<body>
    <header>
        <h1>Hurtownia spożywcza</h1>
    </header>
    <main>
        <h2>Opinie naszych klientów</h2>
        <?php
            $polaczenie = mysqli_connect('localhost','root','','hurtownia');
            $zap1 = mysqli_query($polaczenie,"SELECT klienci.zdjecie, klienci.imie, opinie.opinia FROM klienci JOIN opinie ON klienci.id = opinie.Klienci_id WHERE klienci.Typy_id = 2 || klienci.Typy_id = 3;");
            while ($dane = mysqli_fetch_row($zap1)) {
                echo "
                    <section class='opinia'>
                        <img src='$dane[0]' alt='klient'>
                        <blockquote>
                            $dane[2]
                        </blockquote>
                        <h4>
                            $dane[1]
                        </h4>
                    </section>
                ";
            }
        ?>
    </main>
    <footer>
        <h3>Współpracują z nami</h3>
        <a href="http://sklep.pl">Sklep 1</a>
    </footer>
    <footer>
        <h3>Nasi top klienci</h3>
        <ol>
            <?php
                $zap2 = mysqli_query($polaczenie,"SELECT klienci.imie,klienci.nazwisko,klienci.punkty FROM klienci ORDER BY klienci.punkty DESC LIMIT 3");
                while ($dane = mysqli_fetch_row($zap2)) {
                    echo "<li>$dane[0] $dane[1], $dane[2] pkt</li>";
                }
            ?>
        </ol>
    </footer>
    <footer>
        <h3>Skontaktuj się</h3>
        <p>telefon: 111222333</p>
    </footer>
    <footer>
        <h3>Autor: Maks Noga</h3>
    </footer>
</body>
</html>
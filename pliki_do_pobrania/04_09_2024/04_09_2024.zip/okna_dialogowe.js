alert("UWAGA! YapStreak JK gotowy!");
confirm("Zablokować YapStreak?");
prompt("Podaj nazwę spella");
console.log(window.alert("wth"));
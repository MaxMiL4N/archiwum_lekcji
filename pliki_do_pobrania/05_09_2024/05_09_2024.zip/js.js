console.log("░░░░░░░░░░░░░░░▒▓ Zmienne ▓▒░░░░░░░░░░░░░░");
console.log("░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░");
console.log("░▒▓",a,"Skibidi",him,"             ▓▒░")
console.log("░▒▓                                    ▓▒░");
console.log("░▒▓                                    ▓▒░");
console.log("░▒▓                                    ▓▒░");
console.log("░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░");